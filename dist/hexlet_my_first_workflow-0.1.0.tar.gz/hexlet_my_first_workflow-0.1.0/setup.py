# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hexlet_my_first_workflow']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['say-hello = scripts.say_hello:main']}

setup_kwargs = {
    'name': 'hexlet-my-first-workflow',
    'version': '0.1.0',
    'description': '',
    'long_description': 'hexlet-my-first-workflow\n',
    'author': 'Lev Krasnov',
    'author_email': 'leevakrasnov@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
